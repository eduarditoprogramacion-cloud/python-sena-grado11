# Edunámica

Plataforma web para entrenar el ICFES Saber 11 (grados 9, 10 y 11). Sitio estático de varias páginas, sin instalación.

## Cómo abrirlo

- Opción rápida: abre `index.html` con doble clic.
- Opción recomendada (servidor local): dentro de esta carpeta ejecuta `python3 -m http.server 8000` y entra a http://localhost:8000

Necesita internet solo para las tipografías de Google Fonts. Si no hay conexión, usa tipografías del sistema.

## Estructura

```
edunamica/
├── index.html            Página de inicio (landing)
├── login.html            Iniciar sesión
├── registro.html         Crear cuenta y perfil
├── dashboard.html        Panel principal
├── plan.html             Plan de estudio personalizado
├── practicar.html        Práctica adaptativa por área, diagnóstico y repaso de errores
├── simulacro.html        Simulacros con reloj
├── retos.html            Reto diario, misiones y racha
├── torneos.html          Torneo relámpago y Copa semanal
├── ranking.html          Ranking semanal, histórico y por colegio
├── cursos.html           Mini-lecciones por área
├── leccion.html          Una lección (recibe ?a=ID)
├── cuadernillos.html     Enlaces a cuadernillos oficiales del ICFES
├── logros.html           Insignias, nivel y monedas
├── consejos.html         Consejos y lista del día del examen
├── edu.html              Asistente Edu
├── perfil.html           Editar perfil, contraseña, tema, borrar progreso o cuenta
├── css/styles.css        Estilos (paleta, modo oscuro, responsive, animaciones dinámicas)
├── js/
│   ├── utils.js          Utilidades, fechas, aleatorios e iconos
│   ├── state.js          Cuentas, sesión, progreso, puntaje, niveles y logros
│   ├── ui.js             Avisos, ventanas, menú lateral y arranque de páginas
│   ├── engine.js         Selección adaptativa, práctica y simulacro
│   ├── widgets.js        Medidor, misiones, mapa de constancia y ranking
│   └── pages/            Un archivo por página
├── data/                 Contenido (lo que carga la web)
│   ├── areas.js, preguntas.js, lecturas.js, lecciones.js,
│   │   consejos.js, cuadernillos.js, jugadores.js
│   └── json/             Las mismas tablas en JSON, para otros sistemas
├── database/
│   ├── schema.sql        Esquema para el backend futuro
│   ├── seed.sql          Contenido inicial para esa base de datos
│   ├── export_excel.py   Script unificador y exportador a Excel (.xlsx)
│   └── edunamica_database.xlsx  Base de datos unificada en formato Excel oficial
└── assets/favicon.svg
```

## Cómo funciona hoy

Las cuentas y el progreso se guardan en el `localStorage` del navegador. Cada cuenta tiene su propio espacio. Esto sirve para probar y para demostraciones, pero tiene límites:

- Los datos no viajan entre dispositivos ni navegadores.
- Si se borran los datos del navegador, se pierden.
- La contraseña se guarda con hash SHA-256 y sal, pero al ser todo del lado del cliente no es seguridad real.
- Los jugadores del ranking son de ejemplo (`data/jugadores.js`).
- El asistente Edu responde con reglas locales, no con un modelo de IA.

## Agregar preguntas

Edita `data/preguntas.js`. Cada pregunta es un objeto:

```js
{id:'m11', a:'mat', g:10, d:2, y:2023,
 t:"Enunciado...", o:["A","B","C","D"], c:1, e:"Explicación..."}
```

- `a`: área (`mat`, `lec`, `soc`, `cie`, `ing`)
- `g`: grado (9, 10 u 11) · `d`: dificultad (1 a 3)
- `y`: año del examen de referencia que se muestra bajo la pregunta
- `c`: posición de la opción correcta (0 a 3)
- `p`: (opcional) id de un texto en `data/lecturas.js`

Si el año y el área tienen cuadernillo en `data/cuadernillos.js`, aparece el enlace «Ver cuadernillo oficial».

Las preguntas incluidas son originales, escritas con el formato de Saber 11. No son copias de cuadernillos oficiales. Para usar preguntas oficiales dentro de la plataforma, revisa los términos de uso del ICFES.

## Pasar a un backend real

1. Crea la base con `database/schema.sql` y carga `database/seed.sql`.
2. Reemplaza las funciones de `js/state.js` (`registerUser`, `loginUser`, `save`, `loadState`) por llamadas a tu API.
3. Haz que el servidor calcule el ranking con la vista `weekly_ranking`.
4. Guarda contraseñas con bcrypt o argon2 en el servidor.

## Créditos

Proyecto del Técnico en Programación de Software, I.E. Francisco José de Caldas, Santa Rosa de Cabal. Edunámica no está afiliada al ICFES.
