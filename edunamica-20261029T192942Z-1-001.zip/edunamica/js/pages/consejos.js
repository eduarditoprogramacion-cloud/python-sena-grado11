/* Página: consejos.html */
function tipsV(el){
  const sec=(t,arr)=>`<section class="card"><h3>${t}</h3>${arr.map(([i,h,p])=>`<div class="tip">${ic(i,22)}<div><b>${h}</b><p>${p}</p></div></div>`).join('')}</section>`;
  el.innerHTML=head('Consejos','Estrategias para los retos, los simulacros y la prueba Saber 11 real.')+`<div class="cols2">${sec('Antes del examen',TIPS.before)}${sec('Durante el examen',TIPS.during)}</div>
   <div class="cols2" style="margin-top:16px">${sec('Estrategia por área',TIPS.areas)}<section class="card"><h3>Lista para el día del examen</h3>${EXAM_DAY.map((t,i)=>`<label class="check"><input type="checkbox" data-c="exam${i}" ${S.checks['exam'+i]?'checked':''}><span>${t}</span></label>`).join('')}<p class="muted" style="margin-top:12px;font-size:.9rem">Confirma siempre los detalles oficiales en tu citación y en la página del ICFES.</p></section></div>`;
  $$('[data-c]',el).forEach(c=>c.onchange=()=>{S.checks[c.dataset.c]=c.checked;save()});
}


mountPage('consejos',tipsV);
