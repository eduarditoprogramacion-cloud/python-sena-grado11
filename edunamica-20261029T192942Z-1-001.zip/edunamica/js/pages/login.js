/* Página: login.html */
(function(){
  const root = $('#root'), acc = sessionUser();
  const q = new URLSearchParams(location.search).get('next');
  const next = q && /^[a-z0-9_.-]+\.html(\?[\w=&%-]*)?$/.test(q) ? q : 'dashboard.html';

  root.innerHTML = `
    <div class="auth">
      <div class="auth-side">
        ${logo('index.html')}
        <div>
          <span class="auth-badge">${ic('sparkle', 16)} Bienvenido a tu espacio</span>
          <h2>Qué bueno verte de nuevo</h2>
          <p style="margin-top:14px">Entra y sigue donde lo dejaste: tu racha de estudio, tu plan personalizado y tu posición en el ranking te esperan.</p>
        </div>
        <div class="auth-side-foot">
          <p style="font-size:.9rem;color:#D3E2EA">🔒 Tu progreso se sincroniza y guarda en este dispositivo local.</p>
        </div>
      </div>

      <div class="auth-form">
        <form id="f" novalidate class="auth-card-inner">
          <div class="auth-form-head">
            <h1 style="font-size:2.2rem;margin-bottom:6px">Iniciar sesión</h1>
            <p class="muted">Ingresa tus credenciales para acceder a tu entrenamiento.</p>
          </div>

          ${acc ? `
            <div class="banner" style="margin-top:16px">
              <div class="grow">
                <b>Ya tienes una sesión abierta</b>
                <p class="muted">${esc(acc.profile.name)}</p>
              </div>
              <a class="btn sm" href="dashboard.html">Continuar</a>
            </div>
          ` : ''}

          <div class="field" style="margin-top:20px">
            <label for="email">Correo electrónico</label>
            <div class="input-wrap">
              <span class="input-icon">${ic('user', 18)}</span>
              <input type="email" id="email" inputmode="email" autocomplete="email" placeholder="tucorreo@ejemplo.com" required>
            </div>
          </div>

          <div class="field">
            <div style="display:flex;justify-content:space-between;align-items:center">
              <label for="pw">Contraseña</label>
              <span class="pw-hint-text">Segura y privada</span>
            </div>
            <div class="pw-wrap" id="pw-group">
              <span class="input-icon">${ic('lock', 18)}</span>
              <input type="password" id="pw" autocomplete="current-password" placeholder="Tu contraseña" required>
              <button type="button" class="pw-toggle-btn" id="pw-toggle" aria-label="Mostrar contraseña" title="Mostrar contraseña">
                <span class="pw-icon-eye">${ic('eye', 18)}</span>
              </button>
            </div>
          </div>

          <p class="err" id="err" role="alert"></p>

          <button class="btn lime lg auth-submit-btn" id="go">
            <span>Entrar a Edunámica</span>
            ${ic('arrow', 18)}
          </button>

          <div class="auth-form-footer">
            <p class="muted">¿Aún no tienes cuenta? <a href="registro.html" style="font-weight:700">Crear mi perfil gratis</a></p>
            <div class="auth-extra-links">
              <a href="index.html" class="muted-link">← Volver al inicio</a>
            </div>
          </div>
        </form>
      </div>
    </div>
  `;

  // Toggle de visibilidad de contraseña estilizado
  const pwInput = $('#pw');
  const pwToggle = $('#pw-toggle');
  let pwShown = false;

  pwToggle.addEventListener('click', () => {
    pwShown = !pwShown;
    pwInput.type = pwShown ? 'text' : 'password';
    pwToggle.setAttribute('aria-label', pwShown ? 'Ocultar contraseña' : 'Mostrar contraseña');
    pwToggle.setAttribute('title', pwShown ? 'Ocultar contraseña' : 'Mostrar contraseña');
    pwToggle.innerHTML = pwShown ? ic('eyeOff', 18) : ic('eye', 18);
  });

  // Envío del formulario
  $('#f').onsubmit = async e => {
    e.preventDefault();
    const err = $('#err'), go = $('#go');
    err.textContent = '';
    const email = $('#email').value.trim();
    const pw = $('#pw').value;

    if (!email || !pw) {
      err.textContent = 'Por favor escribe tu correo y contraseña.';
      return;
    }

    go.disabled = true;
    go.classList.add('loading');
    const r = await loginUser(email, pw);
    go.disabled = false;
    go.classList.remove('loading');

    if (r.error) {
      err.textContent = r.error;
      return;
    }
    location.href = next;
  };
})();
