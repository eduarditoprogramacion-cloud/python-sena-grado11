/* Página: leccion.html */
function lessonV(el,id){
  const l=LESSONS.find(x=>x.id===id);if(!l){el.innerHTML=empty('No encontramos esa lección','Vuelve a la lista de cursos.',`<a class="btn" href="cursos.html">Ver cursos</a>`);return}
  const A=AREAS[l.a],done=!!S.lessons[l.id];
  const body=l.b.map(x=>x.startsWith('- ')?null:`<p>${x}</p>`);
  let html='',ul=[];l.b.forEach(x=>{if(x.startsWith('- '))ul.push(`<li>${x.slice(2)}</li>`);else{if(ul.length){html+=`<ul>${ul.join('')}</ul>`;ul=[]}html+=`<p>${x}</p>`}});if(ul.length)html+=`<ul>${ul.join('')}</ul>`;
  el.innerHTML=`<p><a href="cursos.html">Volver a cursos</a></p><div class="pagehead" style="margin-top:12px"><div><span class="pill" style="--ac:${A.c}">${A.n}</span><h1 style="font-size:clamp(1.7rem,3vw,2.4rem);margin-top:10px">${l.t}</h1><p>${l.min} minutos de lectura</p></div></div>
   <div class="card"><div class="prose">${html}</div></div>
   <div class="row" style="margin-top:18px"><button class="btn lime" id="done" ${done?'disabled':''}>${done?'Lección completada':'Marcar como completada, +20 XP'}</button><a class="btn ghost" href="practicar.html?a=${l.a}">Practicar ${A.n}</a></div>`;
  $('#done',el).onclick=()=>{S.lessons[l.id]=dayKey();addXP(20);checkBadges();save();updateChips();toast('Lección completada, +20 XP','good');lessonV(el,id)};
}


mountPage('leccion',lessonV);
