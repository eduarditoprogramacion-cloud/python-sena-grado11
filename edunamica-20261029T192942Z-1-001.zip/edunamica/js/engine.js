/* Motor de preguntas: selección adaptativa, práctica, retos y simulacro */
/* ============ SELECCIÓN DE PREGUNTAS ============ */
function qScore(q,skill,grade){return Math.abs(800+q.d*200-skill)+(S.seen[q.id]||0)*170+(q.g>grade?230:0)+Math.random()*70}
function pickSet(n,{area=null,grade=S.user?S.user.grade:11}={}){
  const out=[],order=weakOrder();
  for(let k=0;k<n;k++){
    const a=area||order[k%5];
    let pool=Q.filter(q=>q.a===a&&!out.includes(q));
    if(!pool.length)pool=Q.filter(q=>(!area||q.a===area)&&!out.includes(q));
    if(!pool.length)break;
    pool.sort((x,y)=>qScore(x,S.skill[x.a],grade)-qScore(y,S.skill[y.a],grade));out.push(pool[0]);
  }
  return out;
}
function dailySet(){
  const r=rng(hash('daily'+dayKey()));
  return AREA_KEYS.map(a=>{const p=Q.filter(q=>q.a===a);return p[Math.floor(r()*p.length)]});
}

/* ============ CORREDOR DE PRÁCTICA ============ */
function runLearn(el,cfg){
  const qs=cfg.qs,n=qs.length;
  if(!n){el.innerHTML=empty('No hay preguntas para esta selección','Prueba con otra área o cambia el nivel.',`<a class="btn" href="practicar.html">Volver a practicar</a>`);return}
  let i=0,okc=0,combo=0,maxc=0,xp=0,tp=0,answered=false,tleft=0,tid=null,order=[],elim=new Set();
  const res=[];
  const onKey=e=>{
    if(e.target.matches('input,textarea,select'))return;
    const k=e.key.toLowerCase();let p='abcd'.indexOf(k);if(p<0)p=['1','2','3','4'].indexOf(k);
    if(p>=0&&!answered){const b=$$('.opt',el)[p];if(b&&!b.disabled)b.click()}
  };
  document.addEventListener('keydown',onKey);
  addCleanup(()=>{clearInterval(tid);document.removeEventListener('keydown',onKey)});
  function tick(){
    const num=$('#tnum',el),fill=$('#tfill',el);if(!num)return;
    num.textContent=tleft;fill.style.width=(tleft/cfg.timer*100)+'%';$('.tbar',el).classList.toggle('warn',tleft<=5);
  }
  function draw(){
    clearInterval(tid);
    if(i>=n)return end();
    const q=qs[i],A=AREAS[q.a];answered=false;elim=new Set();order=shuffle([0,1,2,3]);
    el.innerHTML=`<div class="runner">
     <div class="rhead"><button class="btn ghost sm" id="quit">Salir</button>
      <div class="prog" role="progressbar" aria-label="Progreso" aria-valuemin="0" aria-valuemax="${n}" aria-valuenow="${i}"><i style="width:${i/n*100}%"></i></div>
      <span class="rcount">${i+1} de ${n}</span>${combo>=2?`<span class="combo">${ic('flame',16)} ${combo}</span>`:''}</div>
     ${cfg.timer?`<div class="tbar" role="timer"><i id="tfill"></i><b id="tnum">${cfg.timer}</b></div>`:''}
     <article class="qcard" style="--ac:${A.c}">
      <div class="qmeta"><span class="pill" style="--ac:${A.c}">${A.n}</span><span class="pill soft">Grado ${q.g}</span><span class="pill soft" title="Dificultad ${q.d} de 3">${'●'.repeat(q.d)}${'○'.repeat(3-q.d)}</span></div>
      ${q.p?`<blockquote class="passage">${PASS[q.p]}</blockquote>`:''}
      <h2 class="qtext">${q.t}</h2>
      <div class="opts" role="group" aria-label="Opciones de respuesta">${order.map((oi,p)=>`<button class="opt" data-p="${p}"><span class="ltr">${'ABCD'[p]}</span><span>${q.o[oi]}</span></button>`).join('')}</div>
     </article>
     <p class="qsrc">${srcLine(q)}</p>
     <div id="fb" aria-live="polite"></div>
     <div class="ractions" id="tools">${cfg.hints===false?'':`<button class="btn ghost sm" id="hint">${ic('bulb',16)} Pista, 5 monedas</button>`}<button class="btn ghost sm" id="flag">${ic('flag',16)} ${S.review.includes(q.id)?'Quitar del repaso':'Guardar para repasar'}</button></div></div>`;
    $('#quit',el).onclick=()=>confirmBox('¿Salir de esta sesión? Lo que respondiste ya quedó guardado.','Salir',()=>{location.href=cfg.back||'practicar.html'});
    $$('.opt',el).forEach(b=>b.onclick=()=>pick(+b.dataset.p));
    const h=$('#hint',el);if(h)h.onclick=hint;
    $('#flag',el).onclick=e=>{const has=S.review.includes(q.id);S.review=has?S.review.filter(x=>x!==q.id):[...S.review,q.id];save();e.currentTarget.innerHTML=`${ic('flag',16)} ${has?'Guardar para repasar':'Quitar del repaso'}`};
    if(cfg.timer){tleft=cfg.timer;tick();tid=setInterval(()=>{tleft--;tick();if(tleft<=0){clearInterval(tid);if(!answered)pick(-1)}},1000)}
    window.scrollTo({top:0})
  }
  function hint(){
    if(answered)return;if(S.coins<5){toast('Necesitas 5 monedas para una pista. Las ganas con retos y misiones.','warn');return}
    const q=qs[i];const wr=order.map((oi,p)=>({oi,p})).filter(x=>x.oi!==q.c&&!elim.has(x.p));if(wr.length<=1)return;
    const w=wr[Math.floor(Math.random()*wr.length)];elim.add(w.p);S.coins-=5;save();
    const b=$$('.opt',el)[w.p];b.disabled=true;b.classList.add('dim','struck');updateChips();
  }
  function pick(p){
    if(answered)return;answered=true;clearInterval(tid);
    const q=qs[i],oi=p>=0?order[p]:-1,ok=oi===q.c;
    const g=record(q,ok,cfg.k||32);xp+=g;
    if(ok){okc++;combo++;maxc=Math.max(maxc,combo);if(cfg.timer)tp+=100+tleft*5}else combo=0;
    res.push({q,ok,pick:oi});
    $$('.opt',el).forEach((b,pp)=>{b.disabled=true;if(order[pp]===q.c)b.classList.add('correct');else if(pp===p)b.classList.add('wrong');else b.classList.add('dim')});
    const hb=$('#hint',el);if(hb)hb.disabled=true;
    const head=p<0?'Se acabó el tiempo.':ok?['¡Correcto!','¡Bien resuelto!','Exacto.','Muy bien.'][i%4]:['Casi. Mira por qué.','No era esa. Aquí está la clave.','Error útil: repasa la explicación.'][i%3];
    $('#fb',el).innerHTML=`<div class="fb ${ok?'good':'bad'}"><div><strong>${head}</strong><span class="xpgain">+${g} XP</span></div><p>${q.e}</p></div>
     <div class="ractions" style="margin-top:12px"><span class="grow"></span><button class="btn lime" id="next">${i+1>=n?'Ver resultados':'Siguiente pregunta'}</button></div>`;
    const nx=$('#next',el);nx.onclick=()=>{i++;draw()};nx.focus();updateChips();
  }
  function end(){
    clearInterval(tid);
    const acc=Math.round(okc/n*100);
    const extra=cfg.onEnd?(cfg.onEnd({ok:okc,total:n,res,xp,maxc,tp,acc})||''):'';
    save();updateChips();
    const msg=acc>=80?'Excelente nivel en esta sesión.':acc>=60?'Vas muy bien. Un poco más de práctica y lo afianzas.':acc>=40?'Hay base para construir. Revisa las explicaciones.':'Para esto entrenas: cada error ya quedó en tu repaso.';
    const misses=res.filter(r=>!r.ok);
    el.innerHTML=`<div class="result">
      <div class="ring">${ringSVG(acc,acc>=60?'#2E9E4F':'var(--gold)')}<b>${acc}%</b></div>
      <h2>${esc(cfg.title||'Sesión terminada')}</h2><p class="muted">${msg}</p>
      <div class="kv" style="justify-content:center"><div><b>${okc}/${n}</b><span>Correctas</span></div><div><b>+${xp}</b><span>XP ganados</span></div><div><b>${maxc}</b><span>Mejor racha</span></div></div>
      ${extra}
      ${misses.length?`<div class="rev"><h3 style="margin-bottom:10px">Para repasar</h3>${misses.map(r=>`<details><summary><span class="tag" style="background:${AREAS[r.q.a].c}"></span>${r.q.t.slice(0,90)}${r.q.t.length>90?'…':''}</summary><p><b>Respuesta correcta:</b> ${r.q.o[r.q.c]}</p><p>${r.q.e}</p><p class="qsrc" style="padding:6px 0 0">${srcLine(r.q)}</p></details>`).join('')}</div>`:''}
      <div class="row" style="justify-content:center">${cfg.again?`<button class="btn lime" id="again">${ic('repeat',18)} Otra ronda</button>`:''}<a class="btn ghost" href="${cfg.back||'practicar.html'}">Volver</a><a class="btn ghost" href="dashboard.html">Ir al inicio</a></div></div>`;
    const ag=$('#again',el);if(ag)ag.onclick=cfg.again;window.scrollTo({top:0});
  }
  draw();
}

/* ============ SIMULACRO ============ */
function runExam(el,cfg){
  const qs=cfg.qs,n=qs.length;
  const order=qs.map(()=>shuffle([0,1,2,3])),ans=Array(n).fill(-1),flags=new Set();
  let cur=0,done=false,endAt=Date.now()+cfg.minutes*60000,tid=null;
  addCleanup(()=>clearInterval(tid));
  const mmss=ms=>{const s=Math.max(0,Math.ceil(ms/1000));return`${pad(Math.floor(s/60))}:${pad(s%60)}`};
  function frame(){
    el.innerHTML=`<div class="runner" style="max-width:1000px">
     <div class="row" style="justify-content:space-between"><h2 style="font-size:1.3rem">${esc(cfg.title)}</h2>
      <div class="row"><span class="clock" id="clock" role="timer">${mmss(endAt-Date.now())}</span><button class="btn lime" id="submit">Entregar</button></div></div>
     <div class="xl"><div id="qarea"></div>
      <aside class="card"><h3 style="font-size:1rem">Preguntas</h3><div class="navq" id="navq"></div>
       <p class="muted" style="font-size:.85rem;margin-top:12px">Azul: respondida. Barra dorada: marcada para revisar.</p></aside></div></div>`;
    $('#submit',el).onclick=()=>{const un=ans.filter(a=>a<0).length;confirmBox(un?`Tienes ${un} sin responder. ¿Entregar de todos modos?`:'¿Entregar el simulacro?','Entregar',finish)};
    clearInterval(tid);tid=setInterval(()=>{const c=$('#clock',el);if(!c)return;const left=endAt-Date.now();c.textContent=mmss(left);c.classList.toggle('low',left<60000);if(left<=0)finish()},1000);
    paint();
  }
  function paint(){
    const q=qs[cur],A=AREAS[q.a];
    $('#qarea',el).innerHTML=`<article class="qcard" style="--ac:${A.c}"><div class="qmeta"><span class="pill" style="--ac:${A.c}">${A.n}</span><span class="pill soft">Pregunta ${cur+1} de ${n}</span></div>
      ${q.p?`<blockquote class="passage">${PASS[q.p]}</blockquote>`:''}<h2 class="qtext">${q.t}</h2>
      <div class="opts">${order[cur].map((oi,p)=>`<button class="opt ${ans[cur]===oi?'sel':''}" data-oi="${oi}"><span class="ltr">${'ABCD'[p]}</span><span>${q.o[oi]}</span></button>`).join('')}</div></article>
      <div class="ractions" style="margin-top:12px"><button class="btn ghost sm" id="prev" ${cur===0?'disabled':''}>Anterior</button><button class="btn ghost sm" id="mark">${ic('flag',16)} ${flags.has(cur)?'Quitar marca':'Marcar'}</button><span class="grow"></span><button class="btn sm" id="nxt" ${cur===n-1?'disabled':''}>Siguiente</button></div>`;
    $$('.opt',el).forEach(b=>b.onclick=()=>{ans[cur]=+b.dataset.oi;paint()});
    $('#prev',el).onclick=()=>{cur--;paint()};$('#nxt',el).onclick=()=>{cur++;paint()};
    $('#mark',el).onclick=()=>{flags.has(cur)?flags.delete(cur):flags.add(cur);paint()};
    $('#navq',el).innerHTML=qs.map((_,k)=>`<button class="${ans[k]>=0?'ans':''} ${flags.has(k)?'flg':''} ${k===cur?'cur':''}" data-k="${k}" aria-label="Pregunta ${k+1}">${k+1}</button>`).join('');
    $$('#navq button',el).forEach(b=>b.onclick=()=>{cur=+b.dataset.k;paint()});
  }
  function finish(){
    if(done)return;done=true;clearInterval(tid);
    const used=Math.round((cfg.minutes*60000-Math.max(0,endAt-Date.now()))/60000);
    let ok=0,xp=0;const per={};
    qs.forEach((q,k)=>{const good=ans[k]===q.c;if(good)ok++;xp+=record(q,good,16);
      const p=per[q.a]||(per[q.a]={w:0,t:0,c:0,n:0});p.t+=q.d;p.n++;if(good){p.w+=q.d;p.c++}});
    const sc=a=>per[a]?Math.round(per[a].w/per[a].t*100):areaScore(a);
    const gs=Math.round(5*(3*(sc('mat')+sc('lec')+sc('soc')+sc('cie'))+sc('ing'))/13);
    S.sims.push({date:dayKey(),score:gs,n,ok,min:used,areas:Object.fromEntries(AREA_KEYS.map(a=>[a,per[a]?sc(a):null]))});
    wc().s++;addXP(40);xp+=40;S.coins+=10;checkBadges();save();updateChips();
    const prev=S.sims.length>1?S.sims[S.sims.length-2].score:null;
    el.innerHTML=`<div class="result" style="max-width:860px">
      <div class="ring" style="width:200px">${ringSVG(gs/5,'var(--brand)')}<b style="font-size:2.8rem">${gs}</b></div>
      <h2>Puntaje estimado del simulacro</h2>
      <p class="muted">${ok} de ${n} correctas en ${used} min.${prev!=null?` Antes: ${prev}. ${gs>=prev?'Subiste '+(gs-prev):'Bajaste '+(prev-gs)} puntos.`:''} Es una estimación basada en tus respuestas, no el puntaje oficial.</p>
      <div class="kv" style="justify-content:center"><div><b>+${xp}</b><span>XP</span></div><div><b>+10</b><span>Monedas</span></div></div>
      <div class="card" style="width:100%;text-align:left"><h3>Por área</h3>${AREA_KEYS.map(a=>per[a]?`<div class="arow" style="grid-template-columns:170px 1fr 56px"><span class="nm"><i class="dot" style="--ac:${AREAS[a].c}"></i>${AREAS[a].n}</span><div class="bar" style="--ac:${AREAS[a].c}"><i style="width:${sc(a)}%"></i></div><b>${per[a].c}/${per[a].n}</b></div>`:'').join('')}</div>
      <div class="rev"><h3 style="margin-bottom:10px">Revisión</h3>${qs.map((q,k)=>{const good=ans[k]===q.c;return`<details><summary><span class="tag" style="background:${good?'#2E9E4F':'var(--coral)'}"></span>${k+1}. ${q.t.slice(0,84)}${q.t.length>84?'…':''}</summary><p><b>Tu respuesta:</b> ${ans[k]>=0?q.o[ans[k]]:'Sin responder'}</p><p><b>Correcta:</b> ${q.o[q.c]}</p><p>${q.e}</p><p class="qsrc" style="padding:6px 0 0">${srcLine(q)}</p></details>`}).join('')}</div>
      <div class="row" style="justify-content:center"><a class="btn lime" href="simulacro.html">Otro simulacro</a><a class="btn ghost" href="practicar.html?a=repaso">Repasar errores</a><a class="btn ghost" href="dashboard.html">Ir al inicio</a></div></div>`;
    window.scrollTo({top:0});
  }
  frame();
}

