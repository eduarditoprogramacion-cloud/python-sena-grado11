/* Estado del usuario: cuentas locales, progreso, puntaje, niveles y logros.
   Todo se guarda en localStorage de este navegador. No es seguridad real: para producción
   hace falta un backend con autenticación (ver database/schema.sql). */
const USERS_KEY='edunamica.users',SESSION_KEY='edunamica.session',DATA_PREFIX='edunamica.data.';
let SAVE_KEY=null;
const store={
 get(k){try{return localStorage.getItem(k)}catch(e){return null}},
 set(k,v){try{localStorage.setItem(k,v);return true}catch(e){return false}},
 del(k){try{localStorage.removeItem(k)}catch(e){}},
 ok(){try{localStorage.setItem('__t','1');localStorage.removeItem('__t');return true}catch(e){return false}}
};
const fresh=()=>({user:null,xp:0,coins:20,streak:0,best:0,last:null,combo:0,bestCombo:0,
 skill:{mat:1050,lec:1050,soc:1050,cie:1050,ing:1050},
 stats:{mat:{c:0,t:0},lec:{c:0,t:0},soc:{c:0,t:0},cie:{c:0,t:0},ing:{c:0,t:0}},
 seen:{},review:[],days:{},wk:{},wkc:{},daily:{},dailyCount:0,lessons:{},badges:{},sims:[],tour:{},cups:[],checks:{},
 plan:{min:60,days:[0,1,2,3,4]},theme:'auto',diag:false});
let S=fresh();

/* ---------- cuentas y sesión ---------- */
function getUsers(){try{return JSON.parse(store.get(USERS_KEY)||'[]')}catch(e){return[]}}
function setUsers(u){return store.set(USERS_KEY,JSON.stringify(u))}
const newId=()=>'u'+Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const normEmail=e=>String(e||'').trim().toLowerCase();
async function hashPw(pw,salt){
  const text=salt+':'+pw;
  if(window.crypto&&crypto.subtle){
    const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text));
    return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');
  }
  return'f'+hash(text);
}
function sessionUser(){const id=store.get(SESSION_KEY);return id?getUsers().find(u=>u.id===id)||null:null}
async function registerUser(profile,pw){
  if(!store.ok())return{error:'Tu navegador bloquea el almacenamiento local. Actívalo para poder guardar tu progreso.'};
  const email=normEmail(profile.email),users=getUsers();
  if(users.some(u=>u.email===email))return{error:'Ya existe una cuenta con ese correo. Inicia sesión.'};
  const salt=newId(),id=newId(),p={...profile,email};
  users.push({id,email,salt,hash:await hashPw(pw,salt),created:dayKey(),profile:p});
  setUsers(users);store.set(SESSION_KEY,id);
  SAVE_KEY=DATA_PREFIX+id;S=fresh();S.user=p;save();
  return{ok:true};
}
async function loginUser(email,pw){
  if(!store.ok())return{error:'Tu navegador bloquea el almacenamiento local.'};
  const acc=getUsers().find(u=>u.email===normEmail(email));
  if(!acc||acc.hash!==await hashPw(pw,acc.salt))return{error:'Correo o contraseña incorrectos.'};
  store.set(SESSION_KEY,acc.id);return{ok:true};
}
function logout(){store.del(SESSION_KEY);location.href='login.html'}
function loadState(acc){
  SAVE_KEY=DATA_PREFIX+acc.id;let d=null;
  try{d=JSON.parse(store.get(SAVE_KEY))}catch(e){}
  S=Object.assign(fresh(),d||{});S.user=Object.assign({},acc.profile,S.user||{});
}
function save(){if(SAVE_KEY)store.set(SAVE_KEY,JSON.stringify(S))}
function saveProfile(p){
  const users=getUsers(),acc=users.find(u=>u.id===store.get(SESSION_KEY));
  if(acc){acc.profile={...acc.profile,...p};acc.email=normEmail(acc.profile.email);setUsers(users)}
  S.user={...S.user,...p};save();
}
async function changePassword(oldPw,newPw){
  const users=getUsers(),acc=users.find(u=>u.id===store.get(SESSION_KEY));
  if(!acc||acc.hash!==await hashPw(oldPw,acc.salt))return{error:'La contraseña actual no coincide.'};
  acc.salt=newId();acc.hash=await hashPw(newPw,acc.salt);setUsers(users);return{ok:true};
}
function deleteAccount(){
  const id=store.get(SESSION_KEY);setUsers(getUsers().filter(u=>u.id!==id));store.del(DATA_PREFIX+id);store.del(SESSION_KEY);location.href='index.html';
}

let cleanups=[];const addCleanup=f=>cleanups.push(f);
const runCleanup=()=>{cleanups.forEach(f=>{try{f()}catch(e){}});cleanups=[]};
function applyTheme(){const r=document.documentElement;if(S.theme==='auto')r.removeAttribute('data-theme');else r.dataset.theme=S.theme}
/* ============ PUNTAJE, NIVELES ============ */
const total=()=>AREA_KEYS.reduce((n,a)=>n+S.stats[a].t,0);
const areaScore=a=>clamp(Math.round((S.skill[a]-700)/6.5),0,100);
const globalScore=()=>Math.round(5*(3*(areaScore('mat')+areaScore('lec')+areaScore('soc')+areaScore('cie'))+areaScore('ing'))/13);
const lvl=xp=>Math.floor(Math.sqrt(xp/60))+1;
const lvlStart=l=>60*(l-1)**2;
const lvlPct=()=>{const l=lvl(S.xp);return (S.xp-lvlStart(l))/(lvlStart(l+1)-lvlStart(l))*100};
const wc=()=>{const k=weekKey();return S.wkc[k]||(S.wkc[k]={q:0,d:0,s:0,claimed:{}})};
const weeklyXP=(k=weekKey())=>S.wk[k]||0;
const accArea=a=>S.stats[a].t?Math.round(S.stats[a].c/S.stats[a].t*100):null;
const weakOrder=()=>AREA_KEYS.slice().sort((a,b)=>areaScore(a)-areaScore(b));
const LEAGUES=[['Bronce',0,'#B07A4F'],['Plata',150,'#8FA3AE'],['Oro',400,'#E3A322'],['Diamante',800,'#4FB3E8'],['Élite',1500,'#8B6BC7']];
const leagueOf=x=>LEAGUES.slice().reverse().find(l=>x>=l[1]);

function addXP(n){
  const before=lvl(S.xp);S.xp+=n;const k=weekKey();S.wk[k]=(S.wk[k]||0)+n;
  const after=lvl(S.xp);if(after>before)toast(`${ic('star',18)} Subiste al nivel ${after}`,'good');
}
function touchStreak(){
  const t=dayKey(),y=dayKey(addDays(new Date(),-1));
  if(S.last===t)return;
  S.streak=S.last===y?S.streak+1:1;S.last=t;S.best=Math.max(S.best,S.streak);
  if(S.streak>1)toast(`${ic('flame',18)} Racha de ${S.streak} días`,'good');
}
function streakNow(){const t=dayKey(),y=dayKey(addDays(new Date(),-1));return(S.last===t||S.last===y)?S.streak:0}

function record(q,ok,k=32){
  const a=q.a,st=S.stats[a];st.t++;if(ok)st.c++;
  const qr=800+q.d*200,exp=1/(1+Math.pow(10,(qr-S.skill[a])/400));
  S.skill[a]=clamp(S.skill[a]+k*((ok?1:0)-exp),600,1800);
  S.seen[q.id]=(S.seen[q.id]||0)+1;
  S.combo=ok?S.combo+1:0;S.bestCombo=Math.max(S.bestCombo,S.combo);
  touchStreak();const dk=dayKey();S.days[dk]=(S.days[dk]||0)+1;wc().q++;
  if(ok)S.review=S.review.filter(x=>x!==q.id);else if(!S.review.includes(q.id))S.review.push(q.id);
  const xp=ok?8+q.d*4:2;addXP(xp);checkBadges();save();return xp;
}

/* Logros */
const BADGES=[
 {id:'first',n:'Primer paso',d:'Responde tu primera pregunta',coin:5,ok:()=>total()>=1},
 {id:'q25',n:'Calentando',d:'Responde 25 preguntas',coin:10,ok:()=>total()>=25},
 {id:'q100',n:'Constante',d:'Responde 100 preguntas',coin:25,ok:()=>total()>=100},
 {id:'q500',n:'Máquina',d:'Responde 500 preguntas',coin:80,ok:()=>total()>=500},
 {id:'s3',n:'Tres días seguidos',d:'Racha de 3 días',coin:10,ok:()=>S.best>=3},
 {id:'s7',n:'Semana completa',d:'Racha de 7 días',coin:30,ok:()=>S.best>=7},
 {id:'s30',n:'Mes imparable',d:'Racha de 30 días',coin:150,ok:()=>S.best>=30},
 {id:'c5',n:'Cinco al hilo',d:'5 aciertos seguidos',coin:10,ok:()=>S.bestCombo>=5},
 {id:'c10',n:'Diez al hilo',d:'10 aciertos seguidos',coin:25,ok:()=>S.bestCombo>=10},
 {id:'sim1',n:'Primer simulacro',d:'Termina un simulacro',coin:20,ok:()=>S.sims.length>=1},
 {id:'sim5',n:'Corredor de fondo',d:'Termina 5 simulacros',coin:60,ok:()=>S.sims.length>=5},
 {id:'d1',n:'Reto cumplido',d:'Completa un reto diario',coin:10,ok:()=>S.dailyCount>=1},
 {id:'d7',n:'Reto tras reto',d:'Completa 7 retos diarios',coin:50,ok:()=>S.dailyCount>=7},
 {id:'l5',n:'Estudioso',d:'Completa 5 lecciones',coin:25,ok:()=>Object.keys(S.lessons).length>=5},
 {id:'lv5',n:'Nivel 5',d:'Llega al nivel 5',coin:30,ok:()=>lvl(S.xp)>=5},
 {id:'lv10',n:'Nivel 10',d:'Llega al nivel 10',coin:80,ok:()=>lvl(S.xp)>=10},
 {id:'mast',n:'Dominio de área',d:'80+ en un área con 10 respuestas',coin:40,ok:()=>AREA_KEYS.some(a=>S.stats[a].t>=10&&areaScore(a)>=80)},
 {id:'rayo',n:'Rayo',d:'Juega un torneo relámpago',coin:10,ok:()=>Object.keys(S.tour).length>=1},
 {id:'cup',n:'Copa semanal',d:'Termina una semana en el top 10',coin:60,ok:()=>S.cups.some(c=>c.pos<=10)},
 {id:'g350',n:'Meta 350',d:'Puntaje estimado de 350 o más',coin:60,ok:()=>total()>=30&&globalScore()>=350}
];
function checkBadges(){
  BADGES.forEach(b=>{if(!S.badges[b.id]&&b.ok()){S.badges[b.id]=dayKey();S.coins+=b.coin;toast(`${ic('medal',18)} Logro: ${b.n} (+${b.coin} monedas)`,'good',4200)}});
}
