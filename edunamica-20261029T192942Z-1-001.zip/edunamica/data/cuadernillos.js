/* Cuadernillos oficiales del ICFES (enlaces tomados del índice de Univérsate, sitio sin relación con el ICFES) */
const U='https://universate.co/wp-content/uploads/2023/12/';
const CUAD={
 2023:{cie:U+'Cuadernillo-Ciencias_Naturales-11-1-1.pdf',mat:U+'Cuadernillo-Matematicas-11-1.pdf',soc:U+'Cuadernillo-SocialesyCiudadanas-11-1.pdf',lec:U+'Cuadernillo-LecturaCritica-11-1.pdf',ing:U+'Cuadernillo-Ingles-11-1.pdf'},
 2022:{cie:U+'Cuadernillo-Ciencias_Naturales-11-2022.pdf',mat:U+'Cuadernillo-Matematicas-11-2022.pdf',soc:U+'Cuadernillo-SocialesyCiudadanas-11-2022.pdf',lec:U+'Cuadernillo-LecturaCritica-11-2022.pdf',ing:U+'Cuadernillo-Ingles-11-2022.pdf'},
 2021:{cie:U+'Cuadernillo-Ciencias_Naturales-11-2021.pdf',mat:U+'Matematicas-Grado.11-2021.pdf',soc:U+'Cuadernillo-SocialesyCiudadanas-11-2021.pdf',lec:U+'Cuadernillo-LecturaCritica-11-2021.pdf',ing:U+'Cuadernillo-Ingles-11-2021.pdf'},
 2019:{cie:U+'cuadernillo-de-preguntas-saber-11-ciencias-naturales-2019.pdf',mat:U+'cuadernillo-de-preguntas-saber-11-matematicas-2019.pdf',soc:U+'cuadernillo-de-preguntas-saber-11-sociales-y-ciudadanas-2019.pdf',lec:U+'cuadernillo-de-preguntas-saber-11-lectura-critica-2019.pdf',ing:U+'cuadernillo-de-preguntas-ingles-saber-11-2019.pdf'}
};
const CUAD_SES=[
 ['2025','Primera sesión: Matemáticas, Lectura crítica, Sociales y Ciencias','https://drive.google.com/file/d/1JoB0hEnSL91vPOu1jrh1SdMndSkO4SJD/view?usp=drivesdk'],
 ['2025','Segunda sesión: Sociales, Matemáticas, Ciencias e Inglés','https://drive.google.com/file/d/1W9K_4UuyJnbm0idL-QBgZxm1ZvkbGUUV/view?usp=drivesdk'],
 ['2024-2','Primera sesión: Matemáticas, Lectura crítica, Sociales y Ciencias','https://drive.google.com/file/d/1rbWAfzITMJbFy1vsXCanUKIXRiIY_WoH/view'],
 ['2024-2','Segunda sesión: Sociales, Matemáticas, Ciencias e Inglés','https://drive.google.com/file/d/1XHWetcFXSNL_NS1Ht2N01rOyY1Y0GToN/view?usp=drivesdk'],
 ['2024-1','Primera sesión: Matemáticas, Lectura crítica, Sociales y Ciencias','https://drive.google.com/file/d/12KmtcJHtE29bZlYEKCyMLmj4nxl9p-bd/view']
];
