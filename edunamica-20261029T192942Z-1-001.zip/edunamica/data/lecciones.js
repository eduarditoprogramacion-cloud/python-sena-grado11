/* Mini-lecciones de los cursos */
const LESSONS=[
 {id:'lm1',a:'mat',t:'Porcentajes y proporcionalidad',min:6,b:[
  "Un porcentaje es una fracción de 100. Para calcular el 25 % de una cantidad, multiplica por 0,25 o divide entre 4.",
  "- Descuento: precio final = precio × (1 − descuento).",
  "- Aumento: precio final = precio × (1 + aumento).",
  "- Regla de tres directa: si una cantidad crece, la otra crece en la misma proporción.",
  "Truco ICFES: antes de calcular, estima. Si te piden el 10 % de 480, la respuesta debe ser cercana a 48. Descarta opciones absurdas."]},
 {id:'lm2',a:'mat',t:'Funciones y gráficas',min:7,b:[
  "Una función relaciona cada valor de x con un único valor de y.",
  "- Lineal: y = mx + b. «m» es la pendiente (qué tanto sube) y «b» el corte con el eje y.",
  "- Cuadrática: y = ax² + bx + c. Su gráfica es una parábola. El vértice está en x = −b/2a.",
  "- Exponencial: y = a·bˣ. Crece o decae multiplicando, no sumando.",
  "Truco ICFES: reemplaza valores. Si dudas entre dos gráficas, prueba un punto sencillo como x = 0 o x = 1."]},
 {id:'lm3',a:'mat',t:'Probabilidad y estadística básica',min:6,b:[
  "Probabilidad = casos favorables ÷ casos posibles. Siempre está entre 0 y 1.",
  "- Evento contrario: P(no A) = 1 − P(A).",
  "- Media: suma de datos ÷ cantidad de datos. Mediana: el dato del centro ordenado. Moda: el que más se repite.",
  "- Si agregas un dato mayor que la media, la media sube.",
  "Truco ICFES: lee con calma qué se pide (media, mediana o moda) antes de operar."]},
 {id:'ll1',a:'lec',t:'Cómo encontrar la idea principal',min:5,b:[
  "La idea principal es lo que el texto quiere comunicar. El resto son ejemplos, datos o detalles.",
  "- Pregúntate: si tuviera que resumir el texto en una frase, ¿cuál sería?",
  "- Busca conectores de contraste («sin embargo», «pero»). Lo importante suele venir después.",
  "- Lee la pregunta primero y luego el texto. Así subrayas con un objetivo.",
  "Truco ICFES: las opciones que repiten una palabra del texto pero cambian el sentido suelen ser trampas."]},
 {id:'ll2',a:'lec',t:'Inferir y leer entre líneas',min:6,b:[
  "Inferir es concluir algo que el texto no dice de forma directa, pero que se deduce de lo que dice.",
  "- Fíjate en verbos como «resurge», «desplazó», «aún»: sugieren un antes y un después.",
  "- Distingue ironía, metáfora y sentido literal. Pregúntate qué quiere lograr el autor con esa frase.",
  "- Una buena inferencia siempre se puede apoyar en una frase del texto.",
  "Truco ICFES: si una opción necesita información que no está en el texto, probablemente es incorrecta."]},
 {id:'ls1',a:'soc',t:'Constitución de 1991 y mecanismos de protección',min:7,b:[
  "Colombia es un Estado social de derecho. La Constitución de 1991 reconoce derechos y crea mecanismos para defenderlos.",
  "- Acción de tutela: protege derechos fundamentales de una persona.",
  "- Acción popular: protege derechos colectivos (ambiente sano, espacio público).",
  "- Derecho de petición: pedir información o solicitar algo a una autoridad.",
  "- Participación: voto, plebiscito, referendo, consulta popular, revocatoria del mandato, cabildo abierto, iniciativa legislativa.",
  "Truco ICFES: pregúntate si el caso afecta a una persona o a toda una comunidad."]},
 {id:'ls2',a:'soc',t:'Competencias ciudadanas: analizar perspectivas',min:5,b:[
  "Muchas preguntas presentan un conflicto entre dos o más actores. No piden tu opinión, piden análisis.",
  "- Identifica quién habla, qué quiere y qué le preocupa.",
  "- Diferencia hechos (se pueden comprobar) de opiniones (juicios de valor).",
  "- Busca la opción que respete derechos de todos y use el diálogo.",
  "Truco ICFES: descarta opciones que justifiquen la violencia, la discriminación o ignorar a una de las partes."]},
 {id:'lc1',a:'cie',t:'Leer gráficas y variables',min:6,b:[
  "En ciencias naturales, la mitad del trabajo es interpretar datos.",
  "- Identifica qué hay en cada eje y cuáles son las unidades.",
  "- Variable independiente: la que cambias. Dependiente: la que mides.",
  "- Una recta inclinada indica cambio constante. Una horizontal, que no hay cambio.",
  "Truco ICFES: antes de leer las opciones, describe la gráfica con tus propias palabras."]},
 {id:'lc2',a:'cie',t:'Energía, fuerza y movimiento',min:7,b:[
  "- Segunda ley de Newton: F = m·a.",
  "- Energía cinética: la del movimiento. Energía potencial: la que depende de la altura o posición.",
  "- Sin fricción, la energía mecánica total se conserva: lo que pierde una, lo gana la otra.",
  "- Velocidad constante significa aceleración cero y fuerza neta cero.",
  "Truco ICFES: dibuja el esquema y marca las fuerzas con flechas."]},
 {id:'li1',a:'ing',t:'Tiempos verbales que más aparecen',min:6,b:[
  "- Presente simple: hábitos y hechos. She works. They play.",
  "- Presente continuo: acciones en este momento. He is reading.",
  "- Pasado simple: acciones terminadas. We visited Cali last year.",
  "- Present perfect: puente entre pasado y presente. I have lived here for five years.",
  "- Primer condicional: If it rains, we will stay.",
  "Truco ICFES: busca marcas de tiempo (yesterday, since, for, tomorrow). Te dicen el tiempo verbal."]},
 {id:'li2',a:'ing',t:'Estrategias para las partes de lectura',min:5,b:[
  "El examen de inglés incluye avisos, vocabulario, conversaciones, lectura y gramática en contexto.",
  "- En avisos y letreros, pregúntate dónde verías ese mensaje y qué quiere que hagas.",
  "- En conversaciones, identifica si es una oferta, una invitación o una petición.",
  "- No traduzcas palabra por palabra. Busca el sentido general y las palabras clave.",
  "Truco ICFES: la palabra que no conoces casi nunca es la clave. Sigue leyendo."]}
];
